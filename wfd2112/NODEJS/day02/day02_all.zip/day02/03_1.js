//引入同一级目录下的目录模块03_2
var obj=require('./03_2');
console.log(obj);
console.log(obj.myFn(3,9));