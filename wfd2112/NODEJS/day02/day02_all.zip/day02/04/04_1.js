//引入不以路径开头的目录模块tao
//自动的到node_modules目录中寻找tao
require('tao');