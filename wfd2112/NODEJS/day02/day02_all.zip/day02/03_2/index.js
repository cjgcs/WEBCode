function fn(a,b){
  return a+b;
}
module.exports={
  myFn:fn
}