var a=1;
function fn(){
  return 2;
}
console.log(window.a);
console.log(window.fn());
//创建05.html，把js嵌入运行