/*
console.log(1);  //打印日志
console.info(2); //打印消息
console.warn(3); //打印警告
console.error(4); //打印错误
*/
//开始计时
console.time('tao');
for(var i=1;i<=100000;i++){
}
//结束计时
console.timeEnd('tao');