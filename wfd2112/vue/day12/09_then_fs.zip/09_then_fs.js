//使用then-fs模块读取文件内容  14:15
import thenFs from "then-fs"

thenFs.readFile("./files/1.txt","utf8")
.then((rs)=>{console.log(rs);})
thenFs.readFile("./files/2.txt","utf8")
.then((rs)=>{console.log(rs);})
thenFs.readFile("./files/3.txt","utf8")
.then((rs)=>{console.log(rs);})

