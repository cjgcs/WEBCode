import thenFs from "then-fs";
//等待三个Promise异步对象执行完毕后，执行其它程序
//14:59
const promiseArr = [
    thenFs.readFile("./files/1.txt","utf8"),
    thenFs.readFile("./files/2.txt","utf8"),
    thenFs.readFile("./files/3.txt","utf8")
]
Promise.all(promiseArr).then(([r1,r2,r3])=>{
    console.log(r1,r2,r3);
})
