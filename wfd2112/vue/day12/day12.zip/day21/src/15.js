import thenFs from "then-fs"
console.log("A");//自1
thenFs.readFile("./files/1.txt","utf8").then(rs=>{
    console.log("B");//羊2
})
setTimeout(()=>{
    console.log("C");//羊1  读取时间
},0)
console.log("D");//自2