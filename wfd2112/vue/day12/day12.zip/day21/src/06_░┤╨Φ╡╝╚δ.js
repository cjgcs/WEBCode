//按需导入可以指定别名   13:44
import a,{s1,s2 as ss,say} from "./05_按需导出.js"
console.log(s1,ss,say);
//默认对象
console.log(a);