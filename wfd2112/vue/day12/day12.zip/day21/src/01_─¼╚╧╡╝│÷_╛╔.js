//src/01_默认导出.js
//commonjs 模块使用方法
//1:默认导出
let n1 = 10
let n2 = 20
function show(){}
//旧方法  module.exports 导出
module.exports = {
    n1,
    show
}
