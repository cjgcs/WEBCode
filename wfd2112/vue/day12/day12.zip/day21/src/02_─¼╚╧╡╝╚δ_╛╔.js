//旧 common.js 标准
const m = require("./01_默认导出");
console.log(m.n1,m.show());
