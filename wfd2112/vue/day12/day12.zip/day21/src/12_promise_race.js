import thenFs from "then-fs";

const promiseArr = [
    thenFs.readFile("./files/1.txt","utf8"),
    thenFs.readFile("./files/2.txt","utf8"),
    thenFs.readFile("./files/3.txt","utf8")
]

//三个异步对象只要有一个执行完毕then执行
Promise.race(promiseArr).then((rs)=>{
    console.log(rs);
})
