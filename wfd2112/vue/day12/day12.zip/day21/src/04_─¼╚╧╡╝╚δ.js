//旧 es6 标准
import m from "./03_默认导出.js"
console.log(m.n1,m.show());
