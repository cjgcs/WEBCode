//fz 封装
//1:引入fs模块 15:18
import fs from 'fs'
//2:创建函数 getFile
  //2.1:指定参数 fpath
function getFile(fpath){  
    //2.2:函数内容返回Promise对象
    //resolve() 表示执行成功 reject() 表示执行失败
    return new Promise(function(resolve,reject){
      //2.2.1:读取文件
       fs.readFile(fpath,'utf8',(err,data)=>{
            if(err)return reject(err)
            resolve(data)
       })
      //2.2.2:如果文件读取失败 reject()
      //2.2.4:如果文件读取成功 resolve()
    })
}
//3:测试     15:45 休息一下
getFile("./files/1.txt")
.then((rs)=>{console.log(rs);})
.catch((err)=>{console.log(err);})