import thenFs from "then-fs"
//读取第一个文件   1:45 休息一下
thenFs.readFile("./files/1.txt","utf8")
.then((rs)=>{
    console.log(rs);
    return thenFs.readFile("./files/2.txt","utf8")
}).then((rs)=>{
    console.log(rs);
    return thenFs.readFile("./files/3.txt","utf8") 
}).then((rs)=>{
    console.log(rs);
})