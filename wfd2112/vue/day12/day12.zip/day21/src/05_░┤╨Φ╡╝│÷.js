//按需导出
export let s1 = 'aaa'
export let s2 = 'ccc'
export function say(){}
//默认对象只能导出一次13:38
export default {
    a:20
}