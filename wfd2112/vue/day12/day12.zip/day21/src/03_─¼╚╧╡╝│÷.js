//src/01_默认导出.js
//es6 模块使用方法
//1:默认导出
let n1 = 10
let n2 = 20
function show(){}

//默认导出
export default{
   n1,show
}
//默认导出只能出现一次