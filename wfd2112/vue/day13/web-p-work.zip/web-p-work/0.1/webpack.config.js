module.exports = {
  mode : 'development'
}

//module.exports = {
//  mode: 'development'
//}