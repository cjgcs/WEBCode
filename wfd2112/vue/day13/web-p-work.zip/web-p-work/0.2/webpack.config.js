module.exports = {
  mode : 'production' //development
}

//module.exports = {
//  mode: 'development'
//}