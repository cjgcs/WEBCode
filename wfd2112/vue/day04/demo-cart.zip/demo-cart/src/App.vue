<template>
  <div class="app-container">
    <h1>App 根组件</h1>
  </div>
</template>

<script>
export default {}
</script>

<style lang="less" scoped>
.app-container {
  padding-top: 45px;
  padding-bottom: 50px;
}
</style>
