//src/components/eventBus.js
//1:引入Vue构造函数
import Vue from 'vue'
//2:向外导出Vue实例对象
export default new Vue()