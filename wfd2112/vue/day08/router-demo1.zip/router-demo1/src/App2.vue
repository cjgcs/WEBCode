<template>
  <div class="app-container">
    <h1>App2 组件</h1>
     
    <hr />
    <!--路由链接 以前写法    10:19-->
    <!--a href="#/home">去首页</a  -->
    <router-link to="/home">去首页</router-link>
    <router-link to="/about">去关于</router-link>
    <router-link to="/movie">去电影</router-link>
    <hr />
    <!--动态组件显示不同组件内容,,旧-->
    <!--路由对象容器:功能和动态组件差不同-->
    <router-view></router-view>
    
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="less" scoped>
.app-container {
  background-color: #efefef;
  overflow: hidden;
  margin: 10px;
  padding: 15px;
  > a {
    margin-right: 10px;
  }
}
</style>
