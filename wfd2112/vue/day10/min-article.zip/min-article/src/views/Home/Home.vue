<template>
  <div class="home-container">
   <van-nav-bar
   title="达达头条"
   />
   
  </div>
</template>
<script>
import datalist  from './list'
export default {
   data(){
    return {
      list:datalist
    }
   },
   created(){
   }
}
</script>

<style scoped>
 /*临时覆盖组件专用样式...*/
 .van-nav-bar{
  background-color: #007bff;
 }
 /deep/.van-nav-bar__title{
  color:#fff;
 }
</style>