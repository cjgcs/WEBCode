# DOM03

## 复习

选择器分`3`类

- 按照与已知元素的关系查找:  `children`子元素
- 按照特征查找: `id`, `name`, `class`, `tagName`
- css选择器: `querySelector` 和 `querySelectorAll`

事件

- click:点击
- mouseover: 鼠标悬浮
- mouseenter: 鼠标进入
- mouseleave: 鼠标离开
- focus: 焦点
- blur: 失去焦点
- change: 内容变化
- input: 实时变化
- keyup: 按键抬起
  - 利用 `keyCode` 属性来判断是哪个按键触发
- 事件参数: 通过事件触发的函数,默认接收一个事件参数.  保存了事件相关的各种属性
  - 其中有`target` 属性, 代表触发事件的元素
- 输入框的值存储在 `value` 属性里
- 勾选框的值存储在 `checked` 属性里

属性读取的方式

- 新
  - `元素.属性名`
  - 自定义属性
    - `<标签 data-xxx='值'`
    - 读: `元素.dataset.xxx`  自定义属性存储在 dataset 中
- 旧
  - setAttribute(属性名, 值): 设置
  - getAttribute(属性名) : 读
  - hasAttribute(属性名) : 判断是否有某个属性



## 作业

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>作业 09:10</title>
    <style>
      #box {
        user-select: none;
      }
      #box > div:first-child {
        padding: 10px;
        display: flex;
      }
      #box > div:first-child > span {
        margin: 10px;
        padding: 6px 10px;
      }
      #box > div:first-child > span.active {
        background-color: #00a1d6;
        color: white;
        border-radius: 50px;
      }
      #box > div:last-child > div {
        width: 400px;
        border: 1px solid red;
        display: none;
      }
      #box > div:last-child > div.cur {
        display: block;
      }
    </style>
  </head>
  <body>
    <!-- HTML -> CSS -> JS -->
    <div id="box">
      <div>
        <!-- 利用自定义属性: 标题中存储 对应的 详情元素的id -->
        <span data-id="tab1" class="active">电影</span>
        <span data-id="tab2">电视剧</span>
        <span data-id="tab3">综艺</span>
        <span data-id="tab4">原创</span>
        <span data-id="tab5">新人</span>
      </div>
      <div>
        <div class="cur" id="tab1">
          <img src="./imgs/pj1.png" alt="" />
        </div>
        <div id="tab2">
          <img src="./imgs/pj2.png" alt="" />
        </div>
        <div id="tab3">
          <img src="./imgs/pj3.png" alt="" />
        </div>
        <div id="tab4">
          <img src="./imgs/pj4.png" alt="" />
        </div>
        <div id="tab5">
          <img src="./imgs/pj5.png" alt="" />
        </div>
      </div>
    </div>

    <script>
      const titles = document.querySelectorAll('#box>div:first-child>span')

      titles.forEach(title => {
        title.onclick = function () {
          titles.forEach(v => v.classList.remove('active'))

          this.classList.add('active')

          // 搜索到之前带有 cur 样式的元素, 删除其样式
          const c = document.querySelector('#box .cur')
          c.classList.remove('cur')

          // 读取点击标题的 自定义属性存储的id
          const id = this.dataset.id
          console.log('详情id:', id)
          // 通过id 找到对应的详情元素
          const detail = document.getElementById(id)
          detail.classList.add('cur') //添加cur样式
        }
      })
    </script>
  </body>
</html>

```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>作业: 10:05</title>
    <style>
      #box > span {
        padding: 4px;
        border-radius: 2px;
        color: white;
      }
      #box > span.info {
        background-color: #aaa;
      }
      #box > span.ok {
        background-color: #00dd00;
      }
      #box > span.err {
        background-color: red;
      }
      #box > input {
        padding: 10px;
        font-size: 20px;
        border-radius: 3px;
        border: none;
      }
      body {
        background-color: lightblue;
      }
      #box > span {
        display: none;
      }
      #box > span.active {
        display: inline-block;
      }
    </style>
  </head>
  <body>
    <div id="box">
      <input type="text" />
      <span class="info">用户名长度在6到9位之间</span>
      <span class="err">用户名不能为空</span>
      <span class="ok">用户名可以使用</span>
    </div>

    <script>
      const inp = document.querySelector('input')
      const tips = document.querySelectorAll('#box span')
      console.log(tips)
      // 数组解构语法: 把元素绑定给变量
      const [info, err, ok] = tips
      // 焦点
      inp.onfocus = function () {
        // 如果 当前是正确的, 则终止代码执行, 不执行后续代码
        // ok这个元素, 含有(contains) active 样式
        // 如果ok元素 是激活状态, 则停止执行return
        if (ok.classList.contains('active')) return

        info.classList.add('active')
        err.classList.remove('active')
      }

      // 实时变化
      inp.oninput = function () {
        console.log(this.value)
        const l = this.value.length
        if (l >= 6 && l <= 9) {
          ok.classList.add('active')
          info.classList.remove('active')
        } else {
          ok.classList.remove('active')
          info.classList.add('active')
        }
      }

      // 失去焦点: 如果输入框空的, 则显示err
      inp.onblur = function () {
        if (this.value == '') {
          err.classList.add('active')
          info.classList.remove('active')
        }
      }
    </script>
  </body>
</html>

```

## 事件冒泡

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>事件冒泡机制 10:46</title>
    <style>
      .red {
        width: 500px;
        height: 500px;
        background-color: red;
      }
      .green {
        width: 400px;
        height: 400px;
        background-color: green;
      }
      .blue {
        width: 300px;
        height: 300px;
        background-color: blue;
      }
    </style>
  </head>
  <body>
    <!-- 事件冒泡机制: 子元素触发的事件, 会通知父元素, 触发父元素相同的事件 -->
    <div class="red">
      <div class="green">
        <div class="blue"></div>
      </div>
    </div>

    <script>
      const red = document.querySelector('.red')
      const green = document.querySelector('.green')
      const blue = document.querySelector('.blue')

      red.onclick = function (e) {
        // 由于冒泡机制的存在, 红色的点击事件 不一定是自己被点击后触发
        // 有可能是子元素点击后触发的, 如何 分辨触发者?
        // 事件参数中的 target 属性, 就代表事件直接触发者
        console.log('red: 点击')
        console.log('事件触发者:', e.target)
      }

      green.onclick = function (e) {
        // 阻止冒泡事件:    stop停止 Propagation传播
        // e.stopPropagation()
        console.log('green: 点击')
      }

      blue.onclick = function () {
        console.log('blue: 点击')
      }
    </script>
  </body>
</html>

```

## 事件委托

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>事件委托 11:20</title>
  </head>
  <body>
    <!-- 事件委托: 子元素的事件, 委托给父元素处理 -->
    <div id="box">
      <button>HTML</button>
      <button>CSS</button>
      <button>JS</button>
      <button>Vue</button>
      <p>Hello</p>
    </div>

    <script>
      // 监听按钮的点击事件:
      // 以前: 先查询到所有的按钮, 挨个遍历添加点击事件
      box.onclick = function (e) {
        // 由于冒泡机制: 点击子元素一样会触发父元素box的点击事件
        // 利用标签名 过滤出按钮的点击
        if (e.target.tagName == 'BUTTON') {
          console.log('box:被点击')
        }

        console.dir(e.target)
      }
    </script>
  </body>
</html>

```

## 委托方式:页数

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>页数 11:33</title>

    <style>
      #pages {
        user-select: none;
        background-color: #f5f5f6;
        padding: 10px;
      }
      #pages > span {
        display: inline-block;
        width: 40px;
        line-height: 40px;
        text-align: center;
        background-color: white;
        border-radius: 4px;
        color: #4e6ef2;
      }
      #pages > span.active {
        background-color: #4e6ef2;
        color: white;
      }
    </style>
  </head>
  <body>
    <div id="pages">
      <span class="active">1</span>
      <span>2</span>
      <span>3</span>
      <span>4</span>
      <span>5</span>
    </div>

    <script>
      const pages = document.getElementById('pages')
      // 委托: 给父元素绑定事件
      pages.onclick = function (e) {
        // 委托方式: 一定要过滤出 想要处理的元素的事件
        // e.target: 触发事件的元素
        console.log('target:', e.target)
        console.dir(e.target)
        if (e.target.tagName == 'SPAN') {
          // 查询到之前激活的元素, 清除样式
          const c = document.querySelector('#pages .active')
          c.classList.remove('active')

          e.target.classList.add('active')
        }
      }

      // 场景: 动态新增子元素的场景, 只能用委托实现 -- 下午讲
    </script>
  </body>
</html>

```

## 双标签内容

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>双标签内容 11:54</title>
  </head>
  <body>
    <div id="box">
      <a href="http://tmooc.cn">Welcome to Tmooc</a>
    </div>

    <script>
      const box = document.getElementById('box')
      console.dir(box) // 查看其属性: innerHTML 和 innerText

      // inner: 内部的
      console.log(box.innerHTML) // 标签内容中的 HTML代码
      console.log(box.innerText) // 标签内容中的 文本, 不含HTML标签

      // 修改时的差异:
      // innerHTML: 把值当做是 html 代码来解析
      box.innerHTML = '<h1>Hello</h1>'
      // innerText: 把值作为普通文本进行显示, 不会当做HTML来解析
      box.innerText = '<h1>Hello</h1>'
    </script>
  </body>
</html>

```

## 计数器

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>计数器: 14:08</title>
  </head>
  <body>
    <button>5</button>

    <script>
      // 点击时, 按钮的数字+1
      const btn = document.querySelector('button')

      btn.onclick = function () {
        const n = this.innerHTML // 从标签中读取的内容,都是字符串类型
        console.log('n:', n)
        // +: 有拼接字符串作用. 做数学运算, 要转数字
        // 问题: +   方案1: 把n转数字 *1 parseInt
        // 方案1: 用 - 代替+, 负负得正  +1  == - -1
        // this.innerHTML = n - -1  // 通用性, 适合累加任意数字

        // 如果仅+1, 可以用自增运算符
        this.innerHTML++
      }
    </script>
  </body>
</html>

```

## 计数器升级

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>计数器升级 14:22</title>
  </head>
  <body>
    <div id="box">
      <button>-</button>
      <span>6</span>
      <button>+</button>
    </div>

    <script>
      // 把用到的3个元素分别绑定给不同的变量
      // 查找到 id=box 的所有子元素, 然后解构
      const [btn1, num, btn2] = document.getElementById('box').children
      console.log(document.getElementById('box').children)

      btn1.onclick = function () {
        num.innerHTML--
        // 如果数字是1 则按钮不可用
        if (num.innerHTML == 1) btn1.disabled = true
      }

      btn2.onclick = function () {
        num.innerHTML++
        // 加时, 减按钮 不可用为假
        btn1.disabled = false
      }
    </script>
  </body>
</html>

```

## 购物车cell

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>购物车cell 14:36</title>
    <style>
      table {
        width: 500px;
        /* 边框合并 */
        border-collapse: collapse;
      }

      table > thead {
        background-color: #eee;
      }

      table td,
      table th {
        border: 1px solid gray;
        padding: 4px;
        text-align: center;
      }
    </style>
  </head>

  <body>
    <!-- table>(thead>tr>th*4)+(tbody>tr>td*4) -->
    <table>
      <thead>
        <tr>
          <th>商品名</th>
          <th>单价</th>
          <th>数量</th>
          <th>小计</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>iPhone14</td>
          <td>¥9999</td>
          <td>
            <button disabled>-</button>
            <span>1</span>
            <button>+</button>
          </td>
          <td>¥9999</td>
        </tr>
      </tbody>
    </table>

    <script>
      // 任务1: 实现 + 和 - 按钮的效果
      // 1. 先找到 3个元素: 减按钮  数量  加按钮
      // 2. 实现加按钮的点击效果
      // 3. 实现减按钮的点击效果
      const td = document.querySelector('tbody>tr>td:nth-child(3)')
      console.log(td)
      const [btn1, num, btn2] = td.children

      btn2.onclick = function () {
        num.innerHTML++
        btn1.disabled = false // 不 不可用
        updateTotal()
      }

      btn1.onclick = function () {
        num.innerHTML--
        // 减到1 , 减按钮不可点
        if (num.innerHTML == 1) btn1.disabled = true
        updateTotal()
      }

      // 任务2: 查询出单价, 在数量变化时算出 小计, 更新到后面的小计元素
      // 复用: + 和 - 都要更新小计, 所以更新操作封装成函数
      function updateTotal() {
        const n = num.innerHTML //数量
        // 获取计数器所在元素的 上一个元素
        // previous前一个 Element元素 Sibling兄弟
        const td_price = td.previousElementSibling
        console.log(td_price.innerHTML) // 截取字符串 去掉¥ 可以
        // 用字符串替换, 把¥换成空的: replace(目标字符, 替换成什么)
        const price = td_price.innerHTML.replace('¥', '')
        console.log('price:', price)
        // 下一个兄弟元素
        const td_total = td.nextElementSibling
        console.log(td_total)
        // 小计元素的 内容 赋值为  计算出来的新数据
        td_total.innerHTML = '¥' + n * price
      }
    </script>
  </body>
</html>

```

## 数组转HTML

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>数组转HTML 15:45</title>
  </head>
  <body>
    <ul></ul>
    <!-- 实际开发时: 页面上的数据通常来源自网络, 把数组转HTML是常见操作 -->

    <script>
      var data = ['HTML', 'CSS', 'EXPRESS', 'JS', 'VUE']
      // 把数组的数据, 转换成 HTML代码, 放在li元素里

      // 数组高阶函数: map 映射.  把数组每个元素处理后, 组合成新的数组
      // elements: 元素们, 简称 els;  也可以随便起变量名
      const els = data.map(value => {
        return `<li>${value}</li>`
      })

      console.log(els)
      const ul = document.querySelector('ul')
      // 利用 数组的join方法, 拼接成字符串
      console.log(els.join('')) // 参数是间隔字符, 默认是 逗号

      ul.innerHTML = els.join('')

      // 数组 -> 映射成HTML数组 -> 拼接成字符串 -> 放到页面上
    </script>
  </body>
</html>

```

### 练习

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>练习 16:15</title>
    <style>
      #box > span {
        display: inline-block;
        padding: 5px 10px;
        background-color: #eee;
        border-radius: 3px;
        margin: 0 10px 10px 0;
      }
    </style>
  </head>
  <body>
    <div id="box">
      <!-- 1个示例效果: -->
      <span>番剧</span>
    </div>

    <script>
      var data = ['番剧', '国创', '综艺', '动画', '鬼畜', '电影', '电视剧', '纪录片', '游戏', '音乐']

      // 把每一项放在 span 标签里, 最后加入到id=box 元素里
      var els = data.map(value => {
        // 推荐在HTML中先写个示例, 然后粘贴过来
        return `<span>${value}</span>`
      })

      const box = document.getElementById('box')
      // = 赋值: 新的覆盖旧的
      // += : 累加拼接
      box.innerHTML = els.join('')
    </script>
  </body>
</html>

```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>练习 16:30</title>
    <style>
      #box {
        width: 300px;
        border: 1px solid gray;
      }
      #box > div {
        display: flex;
        justify-content: space-between;
        padding: 10px;
      }
      /* odd:奇数  even:偶数 */
      #box > div:nth-child(odd) {
        background-color: #eee;
      }
    </style>
  </head>
  <body>
    <div id="box">
      <!-- 示例代码 -->
      <div>
        <span>标题</span>
        <span>更新至xxx话</span>
      </div>
    </div>

    <script>
      var data = [
        { title: '我的假女友正...', desc: '更新至27话' },
        { title: '快把我哥带走...', desc: '更新至313话' },
        { title: '非人哉...', desc: '更新至776话' },
        { title: '提督的自我修养...', desc: '更新至50话' },
        { title: '太子有心上人...', desc: '更新至4话' },
      ]
      // 1. 映射成 HTML 的数组.
      var els = data.map(value => {
        // 推荐解构后使用
        const { title, desc } = value

        return `<div>
          <span>${title}</span>
          <span>${desc}</span>
        </div>`
      })
      // 2. 找到box元素
      const box = document.getElementById('box')
      // 3. 拼接成字符串, 放到box元素里
      box.innerHTML = els.join('')
    </script>
  </body>
</html>

```

## 购物车

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>购物车 16:50</title>
    <style>
      table {
        width: 500px;
        /* 边框合并 */
        border-collapse: collapse;
      }

      table > thead {
        background-color: #eee;
      }

      table td,
      table th {
        border: 1px solid gray;
        padding: 4px;
        text-align: center;
      }
    </style>
  </head>

  <body>
    <!-- table>(thead>tr>th*4)+(tbody>tr>td*4) -->
    <table>
      <thead>
        <tr>
          <th>商品名</th>
          <th>单价</th>
          <th>数量</th>
          <th>小计</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>iPhone14</td>
          <td>¥9999</td>
          <td>
            <button disabled>-</button>
            <span>1</span>
            <button>+</button>
          </td>
          <td>¥9999</td>
        </tr>
      </tbody>
    </table>

    <script>
      // 09的代码, 复制到此处, 删除脚本内的
      var data = [
        { name: '苹果', price: 14, count: 10 },
        { name: '香蕉', price: 6, count: 1 },
        { name: '鸭梨', price: 19, count: 20 },
        { name: '葡萄', price: 34, count: 1 },
        { name: '哈密瓜', price: 24, count: 30 },
      ]
      // 任务: 数组映射成 HTML 显示到页面上
      var els = data.map(value => {
        const { name, price, count } = value

        return `<tr>
          <td>${name}</td>
          <td>¥${price}</td>
          <td>
            <button ${count == 1 ? 'disabled' : ''}>-</button>
            <span>${count}</span>
            <button>+</button>
          </td>
          <td>¥${price * count}</td>
        </tr>`
      })

      // 难点1: 每条元素的小计要临时算出来
      // 难点2: 根据数量, 如果是1 则减按钮要添加 disabled 属性, 否则不加
      const tbody = document.querySelector('tbody')
      tbody.innerHTML = els.join('')

      // 找到所有与计数有关的 td
      const tds = document.querySelectorAll('tbody>tr>td:nth-child(3)')
      console.log('tds', tds)

      tds.forEach(td => {
        console.log('td:', td)
        console.dir(td)
        // td: 每一个 计数器所在的 - 这就是案例09 的td
        // 剩余代码和 案例9 一模一样.. 需要自己参考做
        // 1. 从td的子元素里, 解构出3个元素
        // 2. 加按钮 点击操作制作
        // 3. 减按钮 点击操作制作
        // 4. 更新方法制作: updateTotal(), 在 + 和 - 中都要调用触发
        // 搞定...
        const [btn1, num, btn2] = td.children

        btn2.onclick = function () {
          num.innerHTML++
          btn1.disabled = false // 不 不可用
          updateTotal()
        }

        btn1.onclick = function () {
          num.innerHTML--
          // 减到1 , 减按钮不可点
          if (num.innerHTML == 1) btn1.disabled = true
          updateTotal()
        }

        // 任务2: 查询出单价, 在数量变化时算出 小计, 更新到后面的小计元素
        // 复用: + 和 - 都要更新小计, 所以更新操作封装成函数
        function updateTotal() {
          const n = num.innerHTML //数量
          // 获取计数器所在元素的 上一个元素
          // previous前一个 Element元素 Sibling兄弟
          const td_price = td.previousElementSibling
          console.log(td_price.innerHTML) // 截取字符串 去掉¥ 可以
          // 用字符串替换, 把¥换成空的: replace(目标字符, 替换成什么)
          const price = td_price.innerHTML.replace('¥', '')
          console.log('price:', price)
          // 下一个兄弟元素
          const td_total = td.nextElementSibling
          console.log(td_total)
          // 小计元素的 内容 赋值为  计算出来的新数据
          td_total.innerHTML = '¥' + n * price
        }
      })
    </script>
  </body>
</html>

```





















