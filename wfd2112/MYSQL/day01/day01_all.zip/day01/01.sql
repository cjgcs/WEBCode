show databases;
show databases;
show databases;