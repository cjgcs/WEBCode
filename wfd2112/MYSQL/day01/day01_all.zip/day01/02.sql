SHOW 

DATABASES;
USE phpmyadmin;
#SHOW TABLES;
/*
DESC pma__recent;
*/