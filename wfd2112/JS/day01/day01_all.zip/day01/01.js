console.log('hello world');
//console.log('js');
/*
 多行注释
*/