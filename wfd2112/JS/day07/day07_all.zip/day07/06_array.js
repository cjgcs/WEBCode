//构造函数
var arr=new Array('腾讯','阿里','头条');
var course=new Array(3);//初始化长度为3
course[0]='mysql';
course[1]='js';
course[2]='nodejs';
course[3]='html';
//console.log(course);

//练习：创建数组，包含有一组国家的名称；创建数组，初始化长度为5，添加篮球场上5个位置 
//大前锋  小前锋  中锋   得分后卫   控球后卫
var country=new Array('日本','印度','瓦坎达');
var ball=new Array(5);
ball[0]='大前锋';
ball[1]='小前锋';
ball[2]='中锋';
ball[3]='得分后卫';
ball[4]='控球后卫';
//console.log(ball.length);
console.log(ball);











