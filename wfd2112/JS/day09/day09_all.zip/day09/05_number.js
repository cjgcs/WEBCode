var n1=2;//字面量
var n2=new Number(2);//包装对象
//console.log(n2,typeof n2);
//console.log(n1+2,n2+2);
/*
var n=2*3.14*5;
//console.log(n);
//保留小数点后n位
console.log( n.toFixed(2) );
console.log( new Number(n).toFixed(2) );
*/
var total=5000+4888;
console.log(total.toFixed(2));
