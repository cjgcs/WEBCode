var b1=true;//字面量
var b2=new Boolean(true);//包装对象
//console.log(b2,typeof b2);
//false:0 NaN '' undefined null
//{}   []
//console.log( Boolean({}) );
//  !!0->!true->false
console.log(!!0);