var str1='1';//字面量
var str2=new String('1');//包装对象
//强制转为字符串
var str3=String(true);
//console.log(str3,typeof str3);
//console.log(str2,typeof str2);
//console.log(str1+2,str2+2);


//console.log("It's a dog");
//console.log('It"s a dog');
//转义字符 \
//console.log('It\'s a dog');
//console.log('a\nd');
//console.log('a\tb');
console.log('C:\\Users\\web');
