//声明常量
const a=5;
//a=7;
//console.log(a);
//声明常量保存圆周率，声明变量保存半径，计算圆的周长和面积并打印输出
const pi=3.14;
var r=5;
//计算周长
var len=2*pi*r;
//计算面积
var area=pi*r*r;
console.log(len,area);


console.log(2*314*5);
console.log(0.1+0.2);
