//取余
//console.log(5%3);//2
//console.log(3%5);//3
/*
var i=17;
//判断奇数，偶数
console.log(i%2);

var year=2021;
//判断闰年，是否能被4整除
console.log(year%4);


var n=97;
//去除含有的10
console.log(n%10);


var a1=2;
//让a1保存的值在原来基础之上加1
//a1++;
++a1;
console.log(a1);


var a2=5;
//先把当前a2的值赋给a3，然后a2执行自增
var a3=a2++;
console.log(a2,a3);

var a4=5;
//a4先执行自增，然后再把自增的结果赋给a5
var a5=++a4;
console.log(a4,a5);

var  n1=3;
var  n2=n1--;
var  n3=--n1;
console.log(n1,n2,n3);

var  n1=3;
//var n2=n1--;
//var n3=--n1;
//console.log(n2+n3);
console.log(n1-- + --n1);



var m1='2';
//会隐式转换为数字
m1++;
console.log(m1);
*/
//+ - 还有正负的功能，也会隐式转换为数字
var m2=+'2';
console.log(m2,typeof m2);





