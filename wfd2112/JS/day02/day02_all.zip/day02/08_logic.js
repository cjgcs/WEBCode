/*
//判断一个人的工资是否在5000~8000之间
var salary=4000;
console.log(salary>=5000 && salary<=8000);

//练习：声明变量保存用户输入的用户名和密码，判断用户名是否为admin，并且密码为abc123；如果都满足打印true，否则false
var user='tao000';
var pwd='abc123';
console.log(user==='admin' && pwd==='abc123');

//判断是否满足老人或者儿童
var age=65;
console.log(age>=60 || age<=12);

//练习：声明变量保存用户输入的用户名，判断是否为绑定邮箱tao@126.com，或者用户名tao123，或者绑定的手机号码18310238928，如果满足任意一项打印true，否则false
var input='18910238928';
console.log(input==='tao@126.com' || input==='tao123' || input==='18310238928');
*/
//取反
var b=true;
var c=false
//console.log(!b,!c);


var a=2;
//a>1  ||  console.log(num);
a<5  &&  console.log(num);



