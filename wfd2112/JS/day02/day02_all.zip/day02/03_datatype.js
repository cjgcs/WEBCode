/*
var n1=10;
//8进制：以0开头
var n2=012;
//16进制：以0X开头
var n3=0xf;
var n4=314.15;
var n5=3.1415e+2;
var n6=3141.5e-1;
console.log(n4,n5,n6);
//检测是否为数值
console.log( typeof n6 );

//字符串型
var str1='涛';
var str2='3';
var str3='str1';
//console.log(str2,typeof str2);
//console.log(str3);

//查看任意一个字符的Unicode码
console.log( '新涛'.charCodeAt() );

//布尔型
var vip=false;
var a=3>1;//true
console.log(a,typeof a);

//未定义型
var user;//undefined
console.log(user,typeof user);
*/
//空
var p=null;
console.log(p,typeof p);





