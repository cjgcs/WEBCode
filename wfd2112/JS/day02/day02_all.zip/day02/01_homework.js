//练习：声明多个变量，分别保存商品的单价和数量，计算出商品的总价并输出
var price1=20,num1=5;
var price2=18,num2=9;
var total=price1*num1+price2*num2;
//console.log(total);

//练习：交换两个变量的值
var a=1,b=2;
//提前保存a变量的值
var c=a;
a=b;
b=c;

console.log(a,b);

