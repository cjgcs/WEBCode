/*
var n1=2+'3';//'23'
var n2=2+true;//3
var n3=2+false;//2
var n4='3'+true;//'3true'
console.log(n4,typeof n4);


var a=1,b=true,c='tedu';
console.log(a+b+c);//'2tedu'
console.log(b+c+a);//'truetedu1'
console.log(c+a+b);//'tedu1true'


//假设从后端获取了商品的名称和价格
var title='外星人';
var price=13999;
//打印以下效果 
//标题：xxx  价格：xxx
console.log('标题：'+title+'  价格：'+price);

//练习：假设从后端获取了一个员工的数据，包含姓名和工资，最后输出以下效果
//姓名：xxx  工资：xxx
var ename='涛桑';
var salary=50000;
console.log('姓名：'+ename+'  工资：'+salary);
*/


var m1=1+undefined;//NaN
var m2=1+null;//1
var m3='2'*'3';//6
var m4=true/'2';//0.5
var m5='5'-1;//4
var m6='5a'-1;//NaN

//console.log(m6);
console.log(NaN+1, NaN-1,NaN*1,NaN/1);





