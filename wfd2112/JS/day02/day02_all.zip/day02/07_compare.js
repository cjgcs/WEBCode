/*
//console.log(2=='2');//true
//console.log(2==='2');//false
//console.log(1==true);//true
//console.log(1===true);//false
console.log(undefined==null);//true
console.log(undefined===null);

console.log(10>'3');//true

console.log('10'>'3');
console.log( '1'.charCodeAt() );
console.log( '3'.charCodeAt() );
*/
console.log('10a'>3);//false
console.log('10a'<3);//false
console.log('10a'==3);//false
console.log(NaN==NaN);




