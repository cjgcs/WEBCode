//函数声明
function fn(){
}
//匿名函数创建————函数表达式
//变量名称就是函数名称
var fun=function(){
  console.log(1);
}
/*
//fun();
console.log(fun);
console.log(fn);
console.log(typeof fn);//function

//使用匿名函数创建函数getSum，传递任意两个数字，返回两者之间所有整数的和。

//var getSum

var getSum=function(n1,n2){
  //获取n1~n2之间所有整数的和
  for(var i=n1,sum=0;i<=n2;i++){
    sum+=i;
  }
  return sum;
}
console.log( getSum(1,100) );
*/

console.log(c);//function
var c=5;//用5覆盖之前保存的函数
function c(){   //var c=function(){  }
  console.log(2);
}
console.log(c);//5


