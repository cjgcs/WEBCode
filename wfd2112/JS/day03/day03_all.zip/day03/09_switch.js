var n='2';
switch(n){
  case 1:
    console.log('非洲');
    break;
  case 2: //'2'===2
	console.log('印度');
    break;
  case 3:
	console.log('日本');
    break;
  default:
	console.log('八宝山');
}