var a='1';
//在原来基础之上加1
//a++;
//a=a+1;
a+=1;
//console.log(a);

//练习：声明变量保存商品的价格，对价格执行打八折，最后打印结价格
var price=1000;
//在原来的基础之上乘以0.8
price*=0.8;
console.log(price);

var n1=2;
//先执行赋值，然后再执行自增
var n2=n1++;
console.log(n1,n2);



