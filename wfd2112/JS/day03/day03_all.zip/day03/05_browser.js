//弹出警示框
//alert('WEB2112');
//弹出提示(输入)框
//var str=prompt('input user');
//console.log(str,typeof str);



//练习：弹出两次提示框，分别输入数字；计算两个数字相加的和，并将结果以警示框形式弹出。
var n1=prompt('input num1');
var n2=prompt('input num2');

alert(Number(n1)+Number(n2));

