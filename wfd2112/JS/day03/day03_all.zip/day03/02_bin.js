//console.log(3&5);//1
//console.log(5&7);//5
//console.log(6|12);//14
//console.log(7^15);//8
//console.log(7>>1);  //3  //1
console.log(7<<2);